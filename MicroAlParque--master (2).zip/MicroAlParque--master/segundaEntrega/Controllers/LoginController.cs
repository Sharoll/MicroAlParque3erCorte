namespace segundaEntrega.Controllers
{
    public class LoginController
    {
        
    }
}