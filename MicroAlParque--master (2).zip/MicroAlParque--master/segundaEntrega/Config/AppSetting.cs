namespace segundaEntrega.Config
{
    public class AppSetting
    {
        public string Secret { get; set; }
    }
}