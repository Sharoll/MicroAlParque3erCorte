import { FiltroPersonaPipe } from './filtro-persona.pipe';

describe('FiltroPersonaPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroPersonaPipe();
    expect(pipe).toBeTruthy();
  });
});
