export class Restaurantes {
    nit: string;
    nombre: string;
    propietario: string;
    direccion: string;
    cantidadPersonal: number;
    telefono: string;
    email: string;
    sedes: number;
    añoFuncionamiento: number;
    especialidad: string;
}


