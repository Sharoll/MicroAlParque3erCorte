import { Restaurantes } from './restaurantes';

describe('Restaurantes', () => {
  it('should create an instance', () => {
    expect(new Restaurantes()).toBeTruthy();
  });
});
