export class Persona {
    identificacion: string;
    nombres: string;
    apellidos: string;
    edad: number;
    sexo: string;
    telefono: string;
    email: string;
    estadoCivil: string;
    paisProcedencia: string;
    nivelEducativo: string;
    Idrestaurante:string;
}

