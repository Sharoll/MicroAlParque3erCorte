import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-actitudes',
  templateUrl: './actitudes.component.html',
  styleUrls: ['./actitudes.component.css']
})
export class ActitudesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
