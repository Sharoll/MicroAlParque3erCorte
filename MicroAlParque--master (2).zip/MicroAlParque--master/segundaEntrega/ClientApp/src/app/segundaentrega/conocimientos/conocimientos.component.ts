import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conocimientos',
  templateUrl: './conocimientos.component.html',
  styleUrls: ['./conocimientos.component.css']
})
export class ConocimientosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
